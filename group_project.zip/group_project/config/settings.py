# config/settings.py

DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1340337046308524133/cVCHNol11wOs6rQDD6UOgPqI4x_eTqKScIAXN_kD8Ypo_h9wjQNmOeP03Js6OzZPQ7kr"
