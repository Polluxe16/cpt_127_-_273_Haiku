# scraper/news_scraper.py

import requests
from bs4 import BeautifulSoup

def fetch_news_headlines():
    """Fetches the latest news headlines from Google News RSS."""
    rss_url = "https://news.google.com/rss"

    try:
        response = requests.get(rss_url)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"❌ Failed to fetch news: {e}")
        return []

    soup = BeautifulSoup(response.content, "xml")
    news_items = soup.find_all("item")

    return [item.title.text for item in news_items[:10]]  # Get first 10 headlines

# Test the function (optional)
if __name__ == "__main__":
    headlines = fetch_news_headlines()
    for i, headline in enumerate(headlines, 1):
        print(f"{i}. {headline}")
