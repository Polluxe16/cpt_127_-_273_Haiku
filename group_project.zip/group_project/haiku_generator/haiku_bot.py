# haiku_generator/haiku_bot.py

import random
from syllapy import count

def count_syllables(sentence):
    """Counts syllables in a sentence using syllapy."""
    words = sentence.split()
    return sum(count(word) for word in words)

def construct_haiku(headlines):
    """Creates a haiku from the list of headlines."""
    five_syllable_lines = [line for line in headlines if count_syllables(line) == 5]
    seven_syllable_lines = [line for line in headlines if count_syllables(line) == 7]

    if len(five_syllable_lines) < 2 or not seven_syllable_lines:
        return "❌ Not enough headlines to form a haiku today."

    line1 = random.choice(five_syllable_lines)
    line2 = random.choice(seven_syllable_lines)
    line3 = random.choice(five_syllable_lines)
    
    return f"{line1}\n{line2}\n{line3}"

# Test the function (optional)
if __name__ == "__main__":
    test_headlines = [
        "Big storm is coming", 
        "Market drops again today",
        "A new movie out"
    ]
    print(construct_haiku(test_headlines))
