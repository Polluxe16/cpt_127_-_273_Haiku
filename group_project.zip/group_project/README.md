# 📰 News Haiku Bot 🤖

## 📌 Project Overview
This project scrapes **Google News headlines**, generates **haikus**, and posts them to a **Discord channel** using a webhook. The bot is scheduled to run **twice per day** via a cron job.


